package CoffeeServiceManagement;

public interface IKampanya{

	//bu interface kampanyan�n grafikle�tirilemesi haricinde kampanya ile ilgili i�lemler i�in
	public void satis();
	
}
