package CoffeeServiceManagement;

public interface ICustomerDao {
	public void add();
	public void update();
	public void delete();
	public void verify();
}
