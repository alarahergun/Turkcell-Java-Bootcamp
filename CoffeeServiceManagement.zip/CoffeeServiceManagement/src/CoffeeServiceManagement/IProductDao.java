package CoffeeServiceManagement;

public interface IProductDao {
	
	public void add();
	public void delete();
	public void update();
}
