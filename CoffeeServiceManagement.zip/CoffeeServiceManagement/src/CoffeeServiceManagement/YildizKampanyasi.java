package CoffeeServiceManagement;

public class YildizKampanyasi implements IKampanya{

	@Override
	public void satis() {
			System.out.println("M��teri bir y�ld�z kazand�!");
			System.out.println();
	}

	

}
